import { motion } from "framer-motion";
import SectionHeading from "@/components/ui/section-heading";
import { Card, CardContent } from "@/components/ui/card";

const experiences = [
  {
    title: "Data Scientist & AI Engineer",
    company: "Tech Innovation Lab",
    description: "Leading AI and ML projects, developing predictive models, and implementing deep learning solutions. Specialized in NLP and computer vision applications."
  },
  {
    title: "Senior Full Stack Developer",
    company: "Tech Corp",
    description: "Led development of enterprise web applications using React and Node.js. Implemented CI/CD pipelines and mentored junior developers."
  },
  {
    title: "Machine Learning Engineer",
    company: "Data Analytics Co",
    description: "Developed and deployed machine learning models for data analysis and prediction. Worked with TensorFlow, PyTorch, and scikit-learn."
  },
  {
    title: "Full Stack Developer",
    company: "Digital Solutions Inc",
    description: "Created responsive web interfaces and implemented UI/UX designs using modern frontend technologies."
  }
];

export default function Experience() {
  return (
    <section id="experience" className="py-20 bg-black">
      <div className="container mx-auto">
        <SectionHeading 
          title="Experience" 
          subtitle="My professional journey" 
        />

        <div className="mt-12 space-y-6">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
            >
              <Card className="bg-black/50 border border-gray-800">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-xl font-semibold text-white">{exp.title}</h3>
                      <p className="text-gray-300 font-medium">{exp.company}</p>
                    </div>
                    <p className="text-gray-300 max-w-xl">
                      {exp.description}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}