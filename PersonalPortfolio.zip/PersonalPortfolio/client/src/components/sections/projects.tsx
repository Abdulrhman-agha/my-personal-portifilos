import { motion } from "framer-motion";
import SectionHeading from "@/components/ui/section-heading";
import { Card, CardContent } from "@/components/ui/card";

const projects = [
  {
    title: "E-commerce Platform",
    description: "A full-stack e-commerce solution with real-time inventory management",
    technologies: ["React", "Node.js", "PostgreSQL", "Redis"]
  },
  {
    title: "Task Management App",
    description: "Collaborative task management tool with real-time updates",
    technologies: ["Vue.js", "Express", "MongoDB", "WebSocket"]
  },
  {
    title: "Portfolio Website",
    description: "Personal portfolio website built with modern technologies",
    technologies: ["React", "Tailwind CSS", "Framer Motion"]
  }
];

export default function Projects() {
  return (
    <section id="projects" className="py-20 bg-black">
      <div className="container mx-auto">
        <SectionHeading 
          title="Projects" 
          subtitle="Latest Projects" 
        />

        <div className="mt-12 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
            >
              <Card className="bg-black/50 border border-gray-800 h-full">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-2 text-white">{project.title}</h3>
                  <p className="text-gray-300 mb-4">{project.description}</p>

                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech, i) => (
                      <span
                        key={i}
                        className="px-2 py-1 bg-white/10 text-white rounded-md text-sm"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}