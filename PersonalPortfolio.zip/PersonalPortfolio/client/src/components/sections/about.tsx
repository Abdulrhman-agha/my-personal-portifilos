import { motion } from "framer-motion";
import SectionHeading from "@/components/ui/section-heading";

export default function About() {
  return (
    <section id="about" className="py-20 bg-black">
      <div className="container mx-auto">
        <SectionHeading title="About Me" subtitle="Get to know me better" />

        <div className="grid md:grid-cols-2 gap-12 mt-12">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="space-y-4"
          >
            <p className="text-lg text-gray-300">
              Hello! I'm a passionate full-stack developer with over 2 years of experience
              in building web applications. I specialize in creating elegant solutions
              that combine powerful functionality with intuitive user experiences.
            </p>
            <p className="text-lg text-gray-300">
              In the field of Data Science and AI, I've worked extensively with machine learning
              models and deep learning frameworks. My expertise includes developing predictive
              analytics solutions, implementing natural language processing systems, and
              creating computer vision applications.
            </p>
            <p className="text-lg text-gray-300">
              With more than 35 professional certificates across various domains including
              project management, data science, AI, and web development, I bring a comprehensive
              understanding of both technical and managerial aspects to every project.
              These certifications demonstrate my commitment to continuous learning and
              excellence in the field.
            </p>
            <p className="text-lg text-gray-300">
              I continuously explore new technologies and methodologies in both web development
              and data science, always seeking to bridge the gap between powerful analytics
              and user-friendly applications.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="grid grid-cols-2 gap-4"
          >
            <div className="p-4 bg-black/50 border border-gray-800 rounded-lg">
              <h3 className="font-semibold mb-2 text-white">Frontend</h3>
              <p className="text-sm text-gray-300">
                React, Vue, TypeScript, Tailwind CSS
              </p>
            </div>
            <div className="p-4 bg-black/50 border border-gray-800 rounded-lg">
              <h3 className="font-semibold mb-2 text-white">Backend</h3>
              <p className="text-sm text-gray-300">
                Node.js, Python, PostgreSQL, MongoDB
              </p>
            </div>
            <div className="p-4 bg-black/50 border border-gray-800 rounded-lg">
              <h3 className="font-semibold mb-2 text-white">Data Science</h3>
              <p className="text-sm text-gray-300">
                TensorFlow, PyTorch, scikit-learn, NLP
              </p>
            </div>
            <div className="p-4 bg-black/50 border border-gray-800 rounded-lg">
              <h3 className="font-semibold mb-2 text-white">AI & ML</h3>
              <p className="text-sm text-gray-300">
                Deep Learning, Computer Vision, MLOps
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}