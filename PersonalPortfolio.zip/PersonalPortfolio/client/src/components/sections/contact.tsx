import { motion } from "framer-motion";
import { Mail, Instagram } from "lucide-react";
import SectionHeading from "@/components/ui/section-heading";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Contact() {
  return (
    <section id="contact" className="py-20 bg-black">
      <div className="container mx-auto">
        <SectionHeading 
          title="Contact" 
          subtitle="Let's work together" 
        />

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mt-12 max-w-2xl mx-auto"
        >
          <Card className="bg-black/50 border border-gray-800">
            <CardContent className="p-6">
              <div className="text-center space-y-4">
                <p className="text-lg text-gray-300">
                  I'm currently open for freelance projects and full-time positions.
                  Feel free to reach out if you'd like to work together!
                </p>

                <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
                  <Button asChild className="bg-white text-black hover:bg-gray-200">
                    <a href="mailto:abderrhmancontact@gmail.com">
                      <Mail className="h-4 w-4 mr-2" />
                      Email Me
                    </a>
                  </Button>

                  <Button variant="outline" asChild className="border-white text-white hover:bg-white hover:text-black">
                    <a href="https://www.instagram.com/abderrhman_agha?igsh=MTYyeWF5NTg5a3J3eA%3D%3D&utm_source=qr" target="_blank" rel="noopener noreferrer">
                      <Instagram className="h-4 w-4 mr-2" />
                      Instagram
                    </a>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}