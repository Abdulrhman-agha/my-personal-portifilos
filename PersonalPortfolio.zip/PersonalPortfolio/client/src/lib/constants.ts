export const siteConfig = {
  name: "John Doe",
  description: "Full Stack Developer crafting beautiful digital experiences",
  url: "https://johndoe.dev",
  ogImage: "https://johndoe.dev/og.jpg",
  links: {
    github: "https://github.com/johndoe",
    linkedin: "https://linkedin.com/in/johndoe",
    email: "contact@johndoe.dev"
  }
};
